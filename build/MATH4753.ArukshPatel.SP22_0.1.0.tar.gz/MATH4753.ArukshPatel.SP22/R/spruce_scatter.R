spruce_scatter = function(title = FALSE) {
  
  mainTitle = NULL;
  
  if(title == TRUE)
  {
    mainTitle = "Height vs Breast Height Diameter"
  }
  
  plot(Height~BHDiameter,bg="Blue",
       pch = 21, 
       cex = 1.2,
       ylim = c(0, y_max), 
       xlim = c(0, x_max), 
       main = mainTitle, data=spruceCSV)
}